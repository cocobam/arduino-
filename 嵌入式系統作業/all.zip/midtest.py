import serial
import sys
import pymysql
import time
import re
import tkinter
from time import sleep

COM_PORT = 'COM3'
BAUD_RATES = 115200
ser= serial.Serial(COM_PORT,BAUD_RATES)
Celsiu_data=''
Fahrenheid_data=''
Humidity_data=''
cmm_data=''

data = ""
condition = False


def dataupload():
    Arduino_cmd='c'
    cmd=Arduino_cmd.encode('utf-8')
    SerialWrite(cmd)
    condition = False
    try:
       db = pymysql.connect(host="172.20.10.5",user="kokonum",password="ilovevul3a94lkk",db="kokonum")
       cursor1 = db.cursor()
       while True:
          while ser.in_waiting:
             try:
                msg = ser.readline().decode()
                if(msg == ''):
                   continue
                else:
                    print('msg={}'.format(msg))
                    msg_data=re.split(',|:',msg)
    
                    if("攝氏溫度" in str(msg_data[2])) and ("華氏溫度" in str(msg_data[4])) and ("相對濕度" in str(msg_data[0])) and ("感測距離" in str(msg_data[6])) :
                      Celsiu_data=msg_data[1]
                      Fahrenheid_data=msg_data[3]
                      Humidity_data=msg_data[5]
                      cmm_data=msg_data[7].replace(r"\r\n",'')
    
                      cursor1.execute('INSERT INTO `dht` ( `Celsiu`, `Fahrenheit`, `Humidity`, `CM` ) VALUES ( %s, %s, %s, %s)'%( Celsiu_data,Fahrenheid_data,Humidity_data,cmm_data))
    
                      db.commit()
    
                    else:
                      continue
                    print("上傳完成")
                    time.sleep(1)
             except OSError as er:
                db.rollback()
                db.close()
                print(er)
    
    except OSError as er:
       db.rollback()
       db.close()
       print(er)
    
    except KeyboardInterrupt:
       ser.close()
       db.close()
       print('關閉!!')
     
        
     
        
def SerialWrite(command):
    ser.write(command)
    rv = ser.readline()
    
    print(rv.decode("utf-8"))
    data = rv.decode("utf-8")
    print(data)
    sleep(1)
    ser.flushInput()
    
       
       
       
def SendA():
    Arduino_cmd='a'
    cmd=Arduino_cmd.encode('utf-8')
    SerialWrite(cmd)
    condition = False
    
    
def SendB():
    Arduino_cmd='b'
    cmd=Arduino_cmd.encode('utf-8')
    SerialWrite(cmd)
    condition = False
    

    

Tkwindow = tkinter.Tk()
Tkwindow.title("期中考")
Tkwindow.minsize(600,400)
bta = tkinter.Button(Tkwindow,
                     anchor=tkinter.S,
                     text="溫溼度雨刷",
                     width=10,
                     height=1,
                     command=SendA)
bta.pack() 
btb = tkinter.Button(Tkwindow,
                     anchor=tkinter.S,
                     text="倒車雷達",
                     width=10,
                     height=1,
                     command=SendB)
btb.pack()    
btc = tkinter.Button(Tkwindow,
                     anchor=tkinter.S,
                     text="資料上傳",
                     width=10,
                     height=1,
                     command=dataupload)
btc.pack()          
Tkwindow.mainloop()
    
    
    
    
    
    
    
    
    
    
    
    
    


